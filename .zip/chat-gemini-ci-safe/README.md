# Simulação de Ciclo de Integração Contínua com Gemini

## Descrição
Este projeto foi desenvolvido como atividade prática para simular um ciclo moderno de Integração Contínua (CI), integrando uma aplicação Python com a API Gemini do Google.

A aplicação recebe um prompt digitado pelo usuário, envia esse prompt para a API Gemini e exibe a resposta retornada. Além da funcionalidade principal, o projeto também aplica princípios de artesania de software, como Clean Code, SOLID, testes automatizados e pipeline de CI com GitHub Actions.

## Melhorias de segurança e confiabilidade para CI
Esta versão foi ajustada para rodar com mais segurança no GitHub Actions:

- **Testes unitários não dependem da API real**: o CI usa mocks/fakes e uma chave fictícia.
- **Teste de integração real é opcional**: só roda se o segredo `GEMINI_API_KEY` estiver configurado no GitHub.
- **Tratamento explícito de erros**: falhas de configuração ou resposta inválida da API geram exceções específicas.
- **Modelo configurável por variável de ambiente**: `GEMINI_MODEL`.

## Tecnologias utilizadas
- Python 3.11
- Gemini API (Google)
- SDK `google-genai`
- Pytest
- GitHub Actions
- python-dotenv

## Estrutura do projeto

chat-gemini-ci-safe/
├─ app/
│  ├─ main.py
│  ├─ chat_service.py
│  ├─ gemini_client.py
│  ├─ ai_client_interface.py
│  ├─ exceptions.py
│  └─ validator.py
├─ tests/
│  ├─ test_send_prompt.py
│  ├─ test_receive_response.py
│  └─ test_gemini_client.py
├─ .github/workflows/ci.yml
├─ requirements.txt
├─ .env.example
├─ .gitignore
└─ README.md

## Como executar
```bash
python -m venv venv
source venv/bin/activate  # Linux/macOS
# ou venv\Scripts\activate no Windows
pip install -r requirements.txt
cp .env.example .env
# preencha GEMINI_API_KEY no .env
python -m app.main
```

## Como executar os testes
```bash
pytest
```

## Configurar o segredo no GitHub (opcional)
Se você quiser habilitar o teste real de integração com a API Gemini no GitHub Actions:

1. Abra o repositório no GitHub
2. Vá em **Settings > Secrets and variables > Actions**
3. Clique em **New repository secret**
4. Nome: `GEMINI_API_KEY`
5. Valor: sua chave real da Gemini API

Sem esse segredo, o workflow principal continua funcionando normalmente porque roda apenas testes unitários.
