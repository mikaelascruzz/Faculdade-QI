import os
from types import SimpleNamespace
from unittest.mock import MagicMock, patch

import pytest

from app.exceptions import GeminiClientError
from app.gemini_client import GeminiClient


def test_should_raise_error_when_api_key_is_missing(monkeypatch):
    monkeypatch.delenv("GEMINI_API_KEY", raising=False)

    with pytest.raises(GeminiClientError, match="GEMINI_API_KEY"):
        GeminiClient()


@patch("app.gemini_client.genai.Client")
def test_should_return_response_text(mock_genai_client, monkeypatch):
    monkeypatch.setenv("GEMINI_API_KEY", "fake-key")
    fake_sdk_client = MagicMock()
    fake_sdk_client.models.generate_content.return_value = SimpleNamespace(text="Resposta da API")
    mock_genai_client.return_value = fake_sdk_client

    client = GeminiClient()
    result = client.send_prompt("Olá")

    assert result == "Resposta da API"
    fake_sdk_client.models.generate_content.assert_called_once()


@patch("app.gemini_client.genai.Client")
def test_should_raise_error_when_response_has_no_text(mock_genai_client, monkeypatch):
    monkeypatch.setenv("GEMINI_API_KEY", "fake-key")
    fake_sdk_client = MagicMock()
    fake_sdk_client.models.generate_content.return_value = SimpleNamespace(text="")
    mock_genai_client.return_value = fake_sdk_client

    client = GeminiClient()

    with pytest.raises(GeminiClientError, match="não retornou texto"):
        client.send_prompt("Olá")
