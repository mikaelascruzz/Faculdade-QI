from app.chat_service import ChatService


class FakeAIClient:
    def send_prompt(self, prompt: str) -> str:
        return "Olá! Esta é uma resposta simulada do Gemini."


def test_should_return_ai_response_successfully():
    service = ChatService(FakeAIClient())

    response = service.ask("Explique o que é integração contínua")

    assert response == "Olá! Esta é uma resposta simulada do Gemini."
