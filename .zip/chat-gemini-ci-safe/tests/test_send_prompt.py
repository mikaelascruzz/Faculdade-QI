import pytest
from app.chat_service import ChatService


class FakeAIClient:
    def send_prompt(self, prompt: str) -> str:
        return "Resposta simulada"


def test_should_raise_error_when_prompt_is_empty():
    service = ChatService(FakeAIClient())

    with pytest.raises(ValueError, match="O prompt não pode ser vazio."):
        service.ask("")
