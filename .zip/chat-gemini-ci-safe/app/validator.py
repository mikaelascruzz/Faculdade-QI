def validate_prompt(prompt: str) -> None:
    """
    Valida se o prompt foi informado corretamente.
    """
    if prompt is None or prompt.strip() == "":
        raise ValueError("O prompt não pode ser vazio.")
