import os
from google import genai
from app.exceptions import GeminiClientError


class GeminiClient:
    """
    Cliente responsável pela comunicação com a API Gemini.
    """

    def __init__(self):
        api_key = os.getenv("GEMINI_API_KEY")
        if not api_key:
            raise GeminiClientError("A variável GEMINI_API_KEY não foi configurada.")

        self.model = os.getenv("GEMINI_MODEL", "gemini-2.5-flash")
        self.client = genai.Client(api_key=api_key)

    def send_prompt(self, prompt: str) -> str:
        """
        Envia um prompt para a API Gemini e retorna o texto da resposta.
        """
        try:
            response = self.client.models.generate_content(
                model=self.model,
                contents=prompt
            )
        except Exception as error:
            raise GeminiClientError(f"Erro ao chamar a API Gemini: {error}") from error

        text = getattr(response, "text", None)
        if not text or not text.strip():
            raise GeminiClientError("A API Gemini não retornou texto na resposta.")

        return text.strip()
