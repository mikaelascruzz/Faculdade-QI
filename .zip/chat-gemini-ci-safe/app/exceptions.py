class GeminiClientError(Exception):
    """Erro de comunicação ou configuração do cliente Gemini."""
