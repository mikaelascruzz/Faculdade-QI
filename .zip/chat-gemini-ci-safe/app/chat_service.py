from app.ai_client_interface import AIClientProtocol
from app.validator import validate_prompt


class ChatService:
    """
    Camada de serviço responsável por orquestrar o fluxo da aplicação.
    """

    def __init__(self, ai_client: AIClientProtocol):
        self.ai_client = ai_client

    def ask(self, prompt: str) -> str:
        """
        Valida o prompt e delega o envio para o cliente de IA.
        """
        validate_prompt(prompt)
        return self.ai_client.send_prompt(prompt)
