from dotenv import load_dotenv

from app.chat_service import ChatService
from app.exceptions import GeminiClientError
from app.gemini_client import GeminiClient


def main():
    load_dotenv()

    print("=== Chat CLI com Gemini ===")
    prompt = input("Digite sua pergunta: ")

    try:
        gemini_client = GeminiClient()
        service = ChatService(gemini_client)
        response = service.ask(prompt)

        print("\nResposta do Gemini:")
        print(response)

    except ValueError as error:
        print(f"Erro de validação: {error}")
    except GeminiClientError as error:
        print(f"Erro de integração com Gemini: {error}")
    except Exception as error:
        print(f"Erro inesperado: {error}")


if __name__ == "__main__":
    main()
