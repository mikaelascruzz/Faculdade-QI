from typing import Protocol


class AIClientProtocol(Protocol):
    def send_prompt(self, prompt: str) -> str:
        """Envia um prompt e retorna a resposta em texto."""
        ...
